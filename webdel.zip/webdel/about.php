<!DOCTYPE html>
<html>
<head>
	<meta charset = "utf-8">
	<link rel="stylesheet" href="css/style.css" type="text/css">
	<title>About</title>
</head>
<body>
	<div id="container">
		<header>
			<a href = "index.php"><h1>Daily Task Planner</h1></a>
			
		</header>
		 
		
		<nav id="menu">
			<ul>
				<li class="menuitem"><a href="index.php">Home</a></li>
				<li class="menuitem"><a href="about.php">About Us</a></li>
				<li class="menuitem"><a href="contact.php">Contact Us</a></li>
				<li>
					<ul>
						<li class ="signup"><a href = "regUser.php"><button class = "button buttongreen">Sign up</button></a>
						</li>
						<li class ="signin"><a href = "signin.php"><button class = "button buttongreen">Sign in</button></a>
						</li>
					</ul>		
				</li>
				
			</ul>
	    </nav>
		 
		 <!--<aside>
			<nav id="leftmenu">
			<h3>Dashboard</h3>
				<ul>
					<li><a href="browse.php">Manage User</a></li>
					 
					 
				</ul>
			</nav>
		</aside> -->
		
		<section id= "about">
			 
			<h2>Amazing tools to help you get things done</h2>
			<p>We are a chiefly remote team from Malaysia.</p>
			<h1><mark>Our mission is to
			help people organize their task easily so they can make the most of their potential.</mark></h1>
			 
			 
		</section>
		
		 
		
	</div><!--container end-->
	<div style="clear;both"></div>
	<footer>
		Copyright &copy; 2016, Daily Task Planner
	</footer>
</body>
</html>
