<?php

	include "connection.php"; 
	$_SESSION = array(); 
	session_destroy(); ?>
<meta http-equiv="refresh" content="0;index.php">